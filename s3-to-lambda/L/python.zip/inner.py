def from_inner():
    return "from_inner"